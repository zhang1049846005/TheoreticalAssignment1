import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class MainOutPut {
	
	public static void main(String[] args) throws IOException
	{	
		calcaveragescore();			//��ʼ����
	}
		
	public static void calcaveragescore() throws IOException{
		try{
			File mfile = new File("new.txt");
			File file = new File("old.txt");
			ArrayList<lesson> lessonaveragescore = getInformation(file);		//��ȡTXT�ļ���Ϣ
			double averagescore = getAverageaveragescore(lessonaveragescore);		//����ƽ����
			double gpa = getGpa(lessonaveragescore);			//���GPA
			importInfomation(lessonaveragescore,mfile,averagescore,gpa);			//����TXTд����Ϣ
			}
		catch(Exception e){
			e.printStackTrace();
		}
}
		
	public static ArrayList<lesson> getInformation(File file)
	{
		ArrayList<lesson> alesson = new ArrayList<lesson>();
		try{
			InputStreamReader isr = new InputStreamReader(new FileInputStream(file),"Unicode");
			BufferedReader br = new BufferedReader(isr);
			String singleline=null;
			while((singleline=br.readLine())!=null)
			{
				String[] content = singleline.split("\\t+");
				alesson.add(new lesson(content[0],content[1],content[2],Double.parseDouble(content[3]),content[4],content[5],content[6],content[7],content[8],Double.parseDouble(content[9])));
			}
			br.close();				
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return alesson;		
	}	
		
	public static double getAverageaveragescore(ArrayList<lesson> al)
	{
		double averageaveragescore=0;
		double sumcredit=0;
		double sumaveragescore=0;
		for(lesson i:al){
			double credit = i.credit;
			double averagescore = i.averagescore;
			sumcredit = sumcredit + credit;
			sumaveragescore = sumaveragescore + averagescore*credit;
		}
		averageaveragescore = sumaveragescore / sumcredit;
		return averageaveragescore;
	}

	public static double getGpa(ArrayList<lesson> al)
	{
		double sum = 0;
		double average=0;
		double sumcredit=0;
		
		for(lesson i:al)
		{
			double gpa = 0;
			double credit = i.credit;
			double averagescore = i.averagescore;
			sumcredit =+ credit;			
			if (averagescore<=100&&averagescore>=90) {
				gpa=4.0;
			}else if (averagescore>=85&&averagescore<=89) {
				gpa=3.7;
			}else if (averagescore>=82&&averagescore<=84) {
			    gpa=3.3;
			}else if (averagescore>=78&&averagescore<=81) {
				gpa=3.0;
			}else if (averagescore>=75&&averagescore<=77) {
				gpa=2.7;
			}else if (averagescore>=72&&averagescore<=74) {
				gpa=2.3;
			}else if (averagescore>=68&&averagescore<=71) {
				gpa=2.0;
			}else if (averagescore>=64&&averagescore<=67) {
				gpa=1.5;
			}else if (averagescore>=60&&averagescore<=63) {
				gpa=1.0;
			}else if (averagescore<=60) {
				gpa=0;
			}
			sum =+ gpa*credit;
		}
		average = sum / sumcredit; 
		return average;
	}
	
	public static void importInfomation(ArrayList<lesson> lessonaveragescore,File mfile,double averagescore,double gpa) throws IOException
	{
		BufferedWriter cr = new BufferedWriter(new FileWriter(mfile,true));
		for(lesson n:lessonaveragescore)
		{
			cr.write(n.classId+"\t"+n.className+"\t"+n.classType+"\t"+
					n.credit+"\t"+n.teacher +"\t"+n.academy+"\t"+n.type+"\t"+n.year+"\t"+
					n.semester+"\t"+n.averagescore+"\r\n");
		}
		cr.write("ƽ���֣� "+averagescore+"\t\t"+"GPA: "+gpa);
		cr.close();
	}
}

class lesson{
	String classId="";
	String className="";
	String classType="";
	double credit=0;
	String teacher="";
	String academy="";
	String type="";
	String year="";
	String semester="";
	double averagescore=0;
	public lesson(String classId,String className,String classType,double credit,String teacher,String academy,String type,String year,String semester,double averagescore)
	{
		this.classId = classId;
		this.className = className;
		this.classType = classType;
		this.credit = credit;
		this.teacher = teacher;
		this.academy = academy;
		this.type = type;
		this.year = year;
		this.semester = semester;
		this.averagescore = averagescore;
	}
}
